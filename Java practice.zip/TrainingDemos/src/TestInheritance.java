
public class TestInheritance {
	public static void main(String[] args) {
	//Box b = new Box();
	//System.out.println(b);
	GiftBox g1 = new GiftBox();
	System.out.println(g1.getHeight());
	GiftBox g2 = new GiftBox(2,2,2, "Blue");
	System.out.println(g2.getColor());
	System.out.println(g2);
}
}

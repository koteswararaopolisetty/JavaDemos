import java.util.HashMap;


public class MapDemo {
	public static void main(String[] args) {
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		map.put("k1", 1);
		map.put("k2", 4);
		map.put("k3", 9);
		map.put("k4", 12);
		map.put("k5", 25);
		map.put("k1", 35);
		System.out.println(map);
 	}

}


public class GiftBox extends Box1{//use extends keyword to implement inheritance
	String color;
	public GiftBox() {
	super(4,5,6);
	color="Red";
	System.out.println("gift box default constructor");
	//private members are not inherited
	}
	

	public GiftBox(int l, int w, int h, String color) {//constructor with 4 parameters 
		super(l, w, h);
		this.color = color;
	}


	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	@Override
		public String toString() {
			
			return "Gift Box "+super.toString()+",color="+color+"]";
		}
	
}

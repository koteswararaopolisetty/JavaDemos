
public class StaticTest {

	public static void main(String[] args) {
		 StaticDemo sd1 = new StaticDemo();
		 //System.out.println(sd1.s);
		 System.out.println(StaticDemo.s);//Java suggests use static name to print value instead of above statement
		 System.out.println(sd1.ns);
		 StaticDemo sd2 = new StaticDemo();
		 //System.out.println(sd2.s);
		 System.out.println(StaticDemo.s);
		 System.out.println(sd2.ns);
		 StaticDemo sd3 = new StaticDemo();
		 //System.out.println(sd3.s);
		 System.out.println(StaticDemo.s);
		 System.out.println(sd3.ns);
		 StaticDemo sd4 = new StaticDemo();
		 //System.out.println(sd4.s);
		 System.out.println(StaticDemo.s);
		 System.out.println(sd4.ns);
		 
	}

}

package service;

import com.MediaItem.MediaItem;

public interface Library {
	void addItem(MediaItem item);
	boolean searchItem(int id);
	boolean deleteItem(int id);
}


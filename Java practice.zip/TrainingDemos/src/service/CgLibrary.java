package service;

import com.MediaItem.MediaItem;

public class CgLibrary implements Library{

	@Override
	public void addItem(MediaItem item) {
		// TODO Auto-generated method stub
		System.out.println("item added....");
		
	}

	@Override
	public boolean searchItem(int id) {
		// TODO Auto-generated method stub
		System.out.println("searching.........");
		return false;
	}

	@Override
	public boolean deleteItem(int id) {
		// TODO Auto-generated method stub
		System.out.println("deleting..........");
		return false;
	}

}

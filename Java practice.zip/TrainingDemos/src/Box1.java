

public class Box1 {//using shortcuts in eclipse by giving getters and etc in eclipse 

	//data member - instance member/variables
	private int length;
	private int width;
	private int height;
	
	public Box1(int length, int width, int height) {//constructor
		super();
		System.out.println("get param construct");
		this.length = length;
		this.width = width;
		this.height = height;
	}
	
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}

	@Override
	public String toString() {
		return "Box1 [length=" + length + ", width=" + width + ", height="
				+ height + "]";
	}	
}

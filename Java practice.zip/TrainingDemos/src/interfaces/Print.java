package interfaces;

public abstract interface Print {
	final int x=100;
	void printing();

}

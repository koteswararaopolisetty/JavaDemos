package interfaces;

public class Employee implements Print {

	@Override
	public void printing() {
		System.out.println("Employee printing");
		
	}

}

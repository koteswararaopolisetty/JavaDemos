package bean;

public class Test {

	public static void main(String[] args) {
		new Student();
	}
}
